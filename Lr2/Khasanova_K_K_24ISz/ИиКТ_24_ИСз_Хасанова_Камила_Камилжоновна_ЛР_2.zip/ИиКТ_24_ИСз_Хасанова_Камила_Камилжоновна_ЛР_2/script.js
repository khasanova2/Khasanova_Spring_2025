function openModal(title, description, imageSrc) {
    // Устанавливаем заголовок модального окна
    document.getElementById('modal-title').innerText = title;
    // Устанавливаем описание в модальном окне
    document.getElementById('modal-description').innerText = description;
    // Устанавливаем источник изображения в модальном окне
    document.getElementById('modal-image').src = imageSrc;
    // Показываем модальное окно, устанавливая его стиль на "block"
    document.getElementById('myModal').style.display = "block";
}

function closeModal() {
    // Скрываем модальное окно, устанавливая его стиль на "none"
    document.getElementById('myModal').style.display = "none";
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    // Проверяем, был ли клик именно по фону модального окна
    if (event.target == document.getElementById('myModal')) {
        // Если да, то закрываем модальное окно
        closeModal();
    }
}


